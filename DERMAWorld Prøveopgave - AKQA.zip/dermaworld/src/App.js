import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

//Pages
import Frontpage from "./components/pages/frontpage/frontpage";

//Header
import Header from "./components/header/header";

//Footer
import Footer from "./components/footer/footer";

function App() {
  return (
    <Router>
      <section>
        <Header/>
        <Switch>
          {/* Stortset hele hjemmesiden her */}
          <Route path="/" exact component={Frontpage}/>
        </Switch>
        <Footer/>
      </section>
    </Router>
  );
}

export default App;
