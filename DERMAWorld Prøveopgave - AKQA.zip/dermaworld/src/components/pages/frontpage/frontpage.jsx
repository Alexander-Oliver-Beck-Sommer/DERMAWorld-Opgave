import React from "react";
import { Link } from "react-router-dom";

// Importeringer for styles. Hver container har sin egen stylesheet for at kunne nemmere overskue hver af dem
// Generelt kommer alt stylingen til at foregå i SCSS, hvor det derfra bliver compiled til CSS
import "../../styles/bannerShowcase/bannerShowcase.css";
import "../../styles/adtralzaPackage/adtralzaPackage.css";
import "../../styles/threeCircles/threeCircles.css";
import "../../styles/watchVideo/watchVideo.css";
import "../../styles/clinicalTools/clinicalTools.css";
import "../../styles/kolVideos/kolVideos.css";
import "../../styles/references/references.css";

//React icons (bliver brugt til videoernes thumbnail & references knap)
import { AiFillPlayCircle } from "react-icons/ai";
import { IoIosArrowDropdownCircle } from "react-icons/io";

const frontpage = () => {
  return (
    <section>
      {/* <-------------------- BANNER SHOWCASE CONTAINER --------------------> */}
      <section className="banner-showcase_container">
        <img
          src={process.env.PUBLIC_URL + "./images/banner-image-background.jpg"}
          alt="banner background with a blue color ambient"
          className="banner-image-background"
        />
        <div className="banner-text_container">
          <div className="banner-text">
            <img
              src={process.env.PUBLIC_URL + "./images/adtralza-logo.png"}
              alt="adtralza logo with a coloured leaf"
              className="adtralza-logo"
            />
            <h3>
              Adtralza® is a new treatment for adult patients with
              moderate-to-severe atopic dermatitis (eczema) who are candidates
              for systemic therapy.
            </h3>
          </div>
        </div>
        <div className="banner-people_container">
          <img
            src={process.env.PUBLIC_URL + "./images/banner-image-person.png"}
            alt="showcase of the benefits of Adtralza on a person in 3 different stages, from severe atopic dermatitis to healthy"
            className="banner-image-person"
          />
        </div>
      </section>
      {/* <-------------------- BANNER CONTAINER --------------------> */}

      {/* <-------------------- ADTRALZA PACKAGE CONTAINER --------------------> */}
      <section className="adtralza-package_container">
        <div className="adtralza-package_image">
          <img
            src={process.env.PUBLIC_URL + "./images/packshot-package-image.png"}
            alt="adtralza package"
            className="banner-image-background"
          />
        </div>
        <div className="adtralza-package_text">
          <h3>
            It is the first and only biologic developed to specifically
            neutralize IL-13, a key driver of atopic dermatitis signs and
            symptoms(1,2)
          </h3>
          <p>
            Learn more about how Adtralza® works and how to use it in treatment.
          </p>
        </div>
      </section>
      {/* <-------------------- ADTRALZA PACKAGE CONTAINER --------------------> */}

      {/* <-------------------- THREE CIRCLES CONTAINER --------------------> */}
      <section className="three-circles_container">
        <div className="three-circles">
          <img
            src={
              process.env.PUBLIC_URL +
              "./images/sustained-improvement-image.jpg"
            }
            alt="9 out of 10 circle"
            className="banner-image-background"
          />
          <h3>Long term sustained improvement</h3>
          <p>
            9 out of 10 respondents experienced sustained disease control in
            clinical trials 10, providing sustained improvements in the burden
            of disease(1,2, 1, 8*†‡).
          </p>
          <Link to="/learnmore" className="learn-more_link">
            <p>See efficacy and trial data</p>
          </Link>
        </div>

        <div className="three-circles">
          <img
            src={
              process.env.PUBLIC_URL + "./images/improvements-circle-image.jpg"
            }
            alt="a laid out hand with a heart symbom over it"
            className="banner-image-background"
          />
          <h3>Improvements in the burden of disease</h3>
          <p>
            Patients in clinical trials saw an improvement in Quality of Life
            with early symptom relief and sustained improvements in burden of
            disease from week 16 to 32(12,13).
          </p>
          <Link to="/learnmore" className="learn-more_link">
            <p>Learn more about quality of life improvements</p>
          </Link>
        </div>

        <div className="three-circles">
          <img
            src={process.env.PUBLIC_URL + "./images/good-safety-image.jpg"}
            alt="a laid out hand with a little shield over it with a checkmark"
            className="banner-image-background"
          />
          <h3>Good safety profile</h3>
          <p>
            The overall frequency and severity of adverse events with Adtralza®
            were comparable to placebo at 16 weeks* and 52 weeks(19).
          </p>
          <Link to="/learnmore" className="learn-more_link">
            <p>See safety profile </p>
          </Link>
        </div>
      </section>
      {/* <-------------------- THREE CIRCLES CONTAINER --------------------> */}

      {/* <-------------------- WATCH VIDEO CONTAINER --------------------> */}
      <section className="watch-video_container">
        <div className="watch-video_text">
          <h3>
            Adtralza® neutralizes IL-13, a key driver of Atopic Dermatitis signs
            and symptoms.
          </h3>
          <p>
            By specifically targeting the IL-13 cytokine, Adtralza® inhibits the
            interaction with type II receptors and prevents IL-13-induced
            inflammatory responses in the skin(1,2).
          </p>
          <p>
            Adtralza® selectively modulates the dysregulated immune system
            by(1):{" "}
          </p>
          <p>
            — Reducing markers of skin inflammation
            <br />
            — Improving markers of skin barrier integrity
            <br />— Reducing epidermal thickness
          </p>
          <button className="watch-video_button">
            <h3>Watch the video</h3>
          </button>
          <p>Duration: 2:43</p>
        </div>
        <div className="watch-video_image">
          <img
            src={process.env.PUBLIC_URL + "./images/immune-system-image.jpg"}
            alt="Showcase of the immune system being affected by Adtralza"
            className="banner-image-background"
          />
        </div>
      </section>
      {/* <-------------------- WATCH VIDEO CONTAINER --------------------> */}

      {/* <-------------------- CLINICAL TOOLS CONTAINER --------------------> */}
      <section className="clinical-tools_container">
        <div className="clinical-tools_title">
          <h3>Clinical tools - at a glance</h3>
        </div>
        <div className="clinical-tools-items_flex">
          <div className="clinical-tools_items">
            <img
              src={process.env.PUBLIC_URL + "./images/dosing-guide-image.jpg"}
              alt="A smiling nurse with a blue uniform"
              className="banner-image-background"
            />
            <h3>Dosing guide</h3>
            <p>
              Adtralza® has a straightforward dosing regimen, with 150 mg
              prefilled syringes(1).{" "}
            </p>
            <Link to="/learnmore" className="learn-more_links">
              <p>Learn more about application and dosing</p>
            </Link>
          </div>
          <div className="clinical-tools_items">
            <img
              src={
                process.env.PUBLIC_URL + "./images/patient-injection-image.jpg"
              }
              alt="A patient injecting Adtralza into themselves"
              className="banner-image-background"
            />
            <h3>Patient injection made simple</h3>
            <p>
              This step by step video guide shows the patient how to self inject
              using the two syringes that come in the Adtralza® carton.{" "}
            </p>
            <Link to="/learnmore" className="learn-more_links">
              <p>Learn more about application and dosing</p>
            </Link>
          </div>
        </div>
      </section>
      {/* <-------------------- CLINICAL TOOLS CONTAINER --------------------> */}

      {/* <-------------------- KOL VIDEOS CONTAINER --------------------> */}
      <section className="kol-videos_container">
        <div className="kol-videos_title">
          <h3>KOL Videos - get expert insights here</h3>
          <p>
            See what Key opinion leaders have to say about their experiences
            with Adtralza®{" "}
          </p>
        </div>
        <div className="kol-videos-items_flex">
          <div className="kol-videos_items">
            <div className="kol-videos-items_thumbnail">
              <AiFillPlayCircle className="thumbnail-play_button" size="64" />
            </div>
            <div className="kol-videos-items_text">
              <h4>Video title</h4>
              <p>
                Short description of the contents or subject of the video. You
                can upload a screen from the video as thumbnail image
              </p>
            </div>
          </div>
          <div className="kol-videos_items">
            <div className="kol-videos-items_thumbnail">
              <AiFillPlayCircle className="thumbnail-play_button" size="64" />
            </div>
            <div className="kol-videos-items_text">
              <h4>Video title</h4>
              <p>
                Short description of the contents or subject of the video. You
                can upload a screen from the video as thumbnail image
              </p>
            </div>
          </div>
          <div className="kol-videos_items">
            <div className="kol-videos-items_thumbnail">
              <AiFillPlayCircle className="thumbnail-play_button" size="64" />
            </div>
            <div className="kol-videos-items_text">
              <h4>Video title</h4>
              <p>
                Short description of the contents or subject of the video. You
                can upload a screen from the video as thumbnail image
              </p>
            </div>
          </div>
          <div className="kol-videos_items">
            <div className="kol-videos-items_thumbnail">
              <AiFillPlayCircle className="thumbnail-play_button" size="64" />
            </div>
            <div className="kol-videos-items_text">
              <h4>Video title</h4>
              <p>
                Short description of the contents or subject of the video. You
                can upload a screen from the video as thumbnail image
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* <-------------------- KOL VIDEOS CONTAINER --------------------> */}

      {/* <-------------------- REFERENCES CONTAINER --------------------> */}
      <section className="references-container">
        <div className="references-items_flex">
          <IoIosArrowDropdownCircle
            size="64"
            className="references-items_button"
          />
          <h3>References</h3>
        </div>
      </section>
      {/* <-------------------- REFERENCES CONTAINER --------------------> */}
    </section>
  );
};

export default frontpage;
