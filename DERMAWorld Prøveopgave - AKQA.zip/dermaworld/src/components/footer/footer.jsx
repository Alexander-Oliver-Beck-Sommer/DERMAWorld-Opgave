import React from "react";
import "../styles/footer/footer.css";

const footer = () => {
  return (
    <footer className="dermaworld-footer">
      <div className="footer-logo_container">
        <img
          src={process.env.PUBLIC_URL + "./images/leo-footer-logo.png"}
          alt="Leo lion logo"
        />
        <h3>L E O</h3>
      </div>
      <div className="footer-text-container_1">
        <p>© Copyright LEO Pharma 2020</p>
        <p>LEO and the LEO Lion Design</p>
        <p>are registered trademarks</p>
        <p>of LEO Pharma</p>
        <p>All rights reserved</p>
        <h4>LEO Pharma corporate website</h4>
      </div>
      <div className="footer-text-container_2">
        <p>Contact</p>
        <p className="footer-text_dividers">|</p>
        <p>Imprint</p>
        <p className="footer-text_dividers">|</p>
        <p>Conditions</p>
        <p className="footer-text_dividers">|</p>
        <p>Terms of use</p>
        <p className="footer-text_dividers">|</p>
        <p>Privacy</p>
        <p className="footer-text_dividers">|</p>
        <p>Cookie content</p>
      </div>
    </footer>
  );
};

export default footer;
