import React from "react";
import "../styles/header/header.css";

//React Router links i stedet for <a></a> tags
import { Link } from "react-router-dom";

//React icons (De her ikoner bliver brugt til søgefeltet, kryds ikon til når man skal lukke mobil nav og Hamburger icon vice versa.)
import { FaSearch } from "react-icons/fa";
import { ImCross } from "react-icons/im";
import { GiHamburgerMenu } from "react-icons/gi";

const header = () => {
  return (
    // Måden headeren kommer til at virke på, er at der er 3 forskellige sektioner.
    // 1 - Headeren sig selv. Herinde er logoet, søgefeltet og burgermenu ikonet.
    // 2 - Computer navigations menu. Her bliver hele navigations menuen for computer lavet.
    // 3 - Navigations menu for Tablet & Mobil som skal fylde hele siden når man trykker på burgermenu ikonet. Burgermenu ikonet er placeret oppe i sektion 1.
    <header>
      {/* Sektion 1 - Logo og søgefelt */}
      <section className="header-section_1">
        <div className="header-burgermenu-button_container">
          <div onClick={openNav} className="header-burgermenu_button">
            <GiHamburgerMenu size="30" />
          </div>
        </div>
        <div className="header-text-and-searchbar_container">
          <div className="header-logo">
            <h1>
              DERMA<span className="title-span_1">World</span>
            </h1>
            <p>
              By <span className="title-span_2">LEO Pharma</span>
            </p>
          </div>
          <div className="header-searchbar">
            <p>Search</p>
            <FaSearch size="20" />
          </div>
        </div>
      </section>

      {/* Sektion 2 - Computer navigations menu */}
      <nav className="header-section_2">
        <div
          className="computer-navigation-section-1_container"
          id="sectionOne"
        >
          <div className="computer-navigation-section_1">
            <Link to="/computer-links" className="computer-link">
              <p>Bedingungen</p>
            </Link>
            <Link to="/computer-links" className="computer-link" id="linkOne">
              <p>Behandlungen</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Veranstaltungen</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Werkzeuge</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Forschung und Erkenntnisse</p>
            </Link>
          </div>
        </div>
        <div
          className="computer-navigation-section-2_container"
          id="sectionTwo"
        >
          <div></div>
          <div className="computer-navigation-section_2">
            <Link to="/computer-links" className="computer-link" id="linkTwo">
              <p>Adtralza</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Diavonex</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Diavobet</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Enstilar</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Fucidin</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Kyntheum</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Protopic</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Skinoren</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Tralokinumab</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Xamiol</p>
            </Link>
          </div>
        </div>
        <div
          className="computer-navigation-section-3_container"
          id="sectionThree"
        >
          <div className="computer-navigation-section_3">
            <Link to="/computer-links" className="computer-link" id="linkThree">
              <p>Overview</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Mode of Action</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Efficacy</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Quality of Life</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Safety</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Dosing</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>News</p>
            </Link>
            <Link to="/computer-links" className="computer-link">
              <p>Technical Information</p>
            </Link>
          </div>
        </div>
      </nav>
      {/* Sektion 2 - Computer navigations menu */}

      {/* Sektion 3 - Computer navigations menu */}
      <nav className="header-section_3" id="mobilNav">
        <div className="close-nav-icon_container" onClick={closeNav}>
          <ImCross className="close-nav_icon" onClick={closeNav} size="30" />
        </div>
        <Link to="/mobil-links" className="mobil-link_container">
          <h4>Bedingungen</h4>
        </Link>
        <Link to="mobil-links" className="mobil-link_container">
          <h4>Behandlungen</h4>
        </Link>
        <Link to="mobil-links" className="mobil-link_container">
          <h4>Veranstaltungen</h4>
        </Link>
        <Link to="mobil-links" className="mobil-link_container">
          <h4>Werkzeuge</h4>
        </Link>
        <Link to="mobil-links" className="mobil-link_container">
          <h4>Forschung und Erkenntnisse</h4>
        </Link>
      </nav>
      {/* Sektion 2 - Computer navigations menu */}
    </header>
  );
};

function openNav() {
  document.getElementById("mobilNav").style.width = "250px";
}
function closeNav() {
  document.getElementById("mobilNav").style.width = "1px";
}

// ----- Computer navigations menu JavaScript -----
// Som det er lige nu, så vises der kun de links som er blevet vist i mockuppen.
// Derfor bliver der kun brugt de 3 følgende links:
// Behandlungen -> Adtralza -> Overview
window.onload = function () {
  // Variabler for links der aktiverer hover
  var linkOne = document.getElementById("linkOne");
  var linkTwo = document.getElementById("linkTwo");
  // Variabler for sektioner der aktiverer hover
  var sectionTwo = document.getElementById("sectionTwo");
  var sectionThree = document.getElementById("sectionThree");

  // ----- ÅBN ANDEN SEKTION -----
  linkOne.onmouseover = function () {
    expandSecondBox();
  };
  linkOne.onmouseout = function () {
    minimizeSecondBox();
  };
  sectionTwo.onmouseover = function () {
    expandSecondBox();
  };
  sectionTwo.onmouseout = function () {
    minimizeSecondBox();
  };
  function expandSecondBox() {
    document.getElementById("sectionTwo").style.display = "block";
  }
  function minimizeSecondBox() {
    document.getElementById("sectionTwo").style.display = "none";
  }
  // ----- ÅBN ANDEN SEKTION -----

  // ----- ÅBN TREDJE SEKTION -----
  linkTwo.onmouseover = function () {
    expandThirdBox();
  };
  linkTwo.onmouseout = function () {
    minimizeThirdBox();
  };
  sectionThree.onmouseover = function () {
    expandThirdBox();
    expandSecondBox();
  };
  sectionThree.onmouseout = function () {
    minimizeThirdBox();
    minimizeSecondBox();
  };
  function expandThirdBox() {
    document.getElementById("sectionThree").style.display = "block";
  }
  function minimizeThirdBox() {
    document.getElementById("sectionThree").style.display = "none";
  }
  // ----- ÅBN TREDJE SEKTION -----
};

export default header;
